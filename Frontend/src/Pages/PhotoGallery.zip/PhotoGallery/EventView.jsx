import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import ImageModal from "./ImageModal"; // Import modal

const eventDetails = {
  1: {
    title: "Dr. Justice Bidyut Ranjan Sarangi Seminar",
    date: "12.03.2025",
    description:
      "A conference on Human Rights, Right to Skill, and Right to Employment was held in Karnataka, in collaboration with Kodagu University, Laghu Udhyog Bharathi.",
    images: ["/parliament.jpg", "/parliament2.jpg"],
  },
  2: {
    title: "Human Rights Conference in Karnataka",
    date: "12.03.2025",
    description:
      "A discussion on human rights and employment opportunities, featuring renowned legal experts and policymakers.",
    images: ["/parliament.jpg", "/parliament2.jpg"],
  },
};

const EventView = () => {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const event = eventDetails[eventId];

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Open modal with selected image
  const openModal = (index) => {
    setCurrentIndex(index);
    setModalOpen(true);
  };

  // Close modal
  const closeModal = () => {
    setModalOpen(false);
  };

  // Navigate Left
  const prevImage = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? event.images.length - 1 : prevIndex - 1
    );
  };

  // Navigate Right
  const nextImage = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === event.images.length - 1 ? 0 : prevIndex + 1
    );
  };

  return (
    <div className="event-container">
      <button onClick={() => navigate(-1)} className="back-button">
        Back to Gallery
      </button>
      <h2 className="event-heading">Event Details</h2>
      <div className="event-card">
        <p className="event-description">
          <strong>{event.title}</strong>
          <br />
          {event.description}
        </p>
        <p className="event-date">
          <em>Date: {event.date}</em>
        </p>
      </div>
      <div className="event-images">
        {event.images.map((img, index) => (
          <div className="image-container" key={index}>
            <img
              src={img}
              alt={`Event image ${index + 1}`}
              onClick={() => openModal(index)}
              className="clickable-image"
            />
            <span className="image-caption">Event image {index + 1}</span>
          </div>
        ))}
      </div>

      {/* Render ImageModal only when open */}
      {modalOpen && (
        <ImageModal
          images={event.images}
          currentIndex={currentIndex}
          closeModal={closeModal}
          prevImage={prevImage}
          nextImage={nextImage}
        />
      )}
    </div>
  );
};

export default EventView;

