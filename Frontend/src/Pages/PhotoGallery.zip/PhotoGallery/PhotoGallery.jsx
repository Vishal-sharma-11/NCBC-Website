import React from "react";
import { useNavigate } from "react-router-dom";
import image1 from "/parliament.jpg";
import image2 from "/parliament2.jpg";

const events = [
  { id: 1, title: "Dr. Justice Bidyut Ranjan Sarangi Seminar", image: image1 },
  { id: 2, title: "Human Rights Conference in Karnataka", image: image2 },
  { id: 3, title: "Justice V Ramasubramanian's Discourse", image: image1 },
  { id: 4, title: "Justice V Ramasubramanian's Discourse", image: image2 },
  { id: 5, title: "Justice V Ramasubramanian's Discourse", image: image1 },
  { id: 6, title: "Justice V Ramasubramanian's Discourse", image: image2 },
];

const PhotoGallery = () => {
  const navigate = useNavigate();  // Navigation hook for event routing

  return (
    <div className="photogallery-container">
      <h1 className="photogallery-title">Photo Gallery</h1>

      <div className="photogallery-grid">
        {events.map((event) => (
          <div
            key={event.id}
            className="photogallery-card"
            onClick={() => navigate(`/event/${event.id}`)}  // Navigate on click
          >
            <img
              src={event.image}
              alt={event.title}
              className="photogallery-image"
            />
            <p className="photo-caption">{event.title}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PhotoGallery;

